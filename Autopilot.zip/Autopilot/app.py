import tkinter as tk
import time
import random
import threading
import numpy as np
from sklearn.neural_network import MLPClassifier


# Simulate a neural network for decision making
class AutopilotNN:
    def __init__(self):
        self.model = MLPClassifier(hidden_layer_sizes=(10,), max_iter=1000)
        # Training data: [distance_to_obstacle, obstacle_type(0: car, 1: bike, 2: pedestrian)], 0: keep, 1: avoid
        X = np.array([[10, 0], [10, 1], [10, 2], [5, 0], [5, 1], [5, 2], [2, 0], [2, 1], [2, 2]])
        y = np.array([0, 1, 1, 1, 1, 1, 1, 1, 1])
        self.model.fit(X, y)

    def predict(self, distance, obstacle_type):
        return self.model.predict([[distance, obstacle_type]])[0]


class Car:
    def __init__(self, canvas, width, height, autopilot):
        self.speed = 5
        self.direction = "Forward"
        self.obstacle_detected = False
        self.canvas = canvas
        self.car_shape = canvas.create_rectangle(width // 2 - 25, height - 100, width // 2 + 25, height - 50,
                                                 fill="blue")
        self.alert_text = canvas.create_text(width // 2, 20, text="", fill="red", font=("Helvetica", 16))
        self.obstacle_shapes = []
        self.traffic_lights = []
        self.width = width
        self.height = height
        self.running = False
        self.manual_control = False
        self.autopilot = autopilot
        self.destination = (width // 2, 50)  # Point B

    def accelerate(self):
        if self.speed < 100:
            self.speed += 5
            self.update_canvas()
        print(f"Accelerating. Current speed: {self.speed} km/h")

    def decelerate(self):
        if self.speed > 0:
            self.speed = max(0, self.speed - 5)
            self.update_canvas()
        print(f"Decelerating. Current speed: {self.speed} km/h")

    def turn_left(self, event=None):
        if self.manual_control:
            self.direction = "Left"
            print("Turning left.")
            self.update_canvas()

    def turn_right(self, event=None):
        if self.manual_control:
            self.direction = "Right"
            print("Turning right.")
            self.update_canvas()

    def move_forward(self):
        self.direction = "Forward"
        print("Moving forward.")
        self.update_canvas()

    def detect_obstacle(self):
        if len(self.obstacle_shapes) < 10:  # Limit the number of obstacles
            obstacle_position = random.randint(0, self.width - 50)
            obstacle_type = random.choice([0, 1, 2])  # 0: car, 1: bike, 2: pedestrian
            obstacle_color = "red" if obstacle_type == 0 else "green" if obstacle_type == 1 else "yellow"
            shape = self.canvas.create_rectangle(obstacle_position, 50, obstacle_position + 50, 100,
                                                 fill=obstacle_color)
            self.obstacle_shapes.append((shape, obstacle_type))
        self.obstacle_detected = True

    def avoid_obstacle(self):
        if self.obstacle_shapes:
            for shape, obstacle_type in self.obstacle_shapes:
                obstacle_coords = self.canvas.coords(shape)
                car_coords = self.canvas.coords(self.car_shape)
                distance = abs(car_coords[1] - obstacle_coords[3])
                action = self.autopilot.predict(distance, obstacle_type)
                if action == 1:  # Avoid obstacle
                    self.turn_left() if random.choice([True, False]) else self.turn_right()
                    self.canvas.move(shape, 0, 5)
                    print("Avoiding obstacle!")
                    self.canvas.itemconfig(self.alert_text, text="Warning: Obstacle detected!")
                else:
                    self.canvas.itemconfig(self.alert_text, text="")

    def respect_traffic_lights(self):
        for light in self.traffic_lights:
            light_coords = self.canvas.coords(light)
            car_coords = self.canvas.coords(self.car_shape)
            if abs(car_coords[1] - light_coords[3]) < 50 and self.canvas.itemcget(light, "fill") == "red":
                self.stop()
                self.canvas.itemconfig(self.alert_text, text="Stopping at red light")
                return True
        return False

    def update_canvas(self):
        car_coords = self.canvas.coords(self.car_shape)
        if car_coords[1] <= self.destination[1]:
            self.stop()
            self.canvas.itemconfig(self.alert_text, text="Arrived at destination")
            return
        if self.direction == "Left":
            self.canvas.move(self.car_shape, -10, 0)
        elif self.direction == "Right":
            self.canvas.move(self.car_shape, 10, 0)
        elif self.direction == "Forward":
            self.canvas.move(self.car_shape, 0, -10)
        self.canvas.update()

    def create_traffic_lights(self):
        for _ in range(3):
            x = random.randint(50, self.width - 50)
            light = self.canvas.create_rectangle(x, 0, x + 50, 50, fill=random.choice(["red", "green"]))
            self.traffic_lights.append(light)

    def run(self):
        self.running = True
        self.create_traffic_lights()
        self.schedule_next_step()

    def schedule_next_step(self):
        if self.running:
            if not self.manual_control:
                if not self.respect_traffic_lights():
                    self.detect_obstacle()
                    self.avoid_obstacle()
                    self.move_forward()
            self.canvas.after(1000 // self.speed, self.schedule_next_step)

    def stop(self):
        self.running = False


def main():
    root = tk.Tk()
    root.title("Autonomous Car Simulation")

    width, height = 800, 600
    canvas = tk.Canvas(root, width=width, height=height, bg="white")
    canvas.pack()

    autopilot = AutopilotNN()
    my_car = Car(canvas, width, height, autopilot)

    def start_simulation():
        my_car.manual_control = False
        my_car.run()

    def stop_simulation():
        my_car.stop()

    def take_control():
        my_car.manual_control = True

    start_button = tk.Button(root, text="Start Autopilot", command=start_simulation)
    start_button.pack(side=tk.LEFT)

    stop_button = tk.Button(root, text="Stop", command=stop_simulation)
    stop_button.pack(side=tk.RIGHT)

    manual_button = tk.Button(root, text="Take Control", command=take_control)
    manual_button.pack(side=tk.BOTTOM)

    root.bind("<Left>", my_car.turn_left)
    root.bind("<Right>", my_car.turn_right)

    root.mainloop()


if __name__ == "__main__":
    main()
